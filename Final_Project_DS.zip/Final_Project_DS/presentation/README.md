# Final Project for Intro to Data Science

Here is a copy of the presentation used to discuss the results of the final project. 

(You can include a `.pptx` or `.pdf` version of your presentation here)