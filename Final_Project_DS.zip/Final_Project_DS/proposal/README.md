# Preliminary Analysis

The file `ideas.Rmd` includes preliminary ideas for the project, including initial exploratory data analysis questions, plan for data exploration, etc.

