# Final Project for Intro to Data Science

This folder includes as copy of the **final project report** for the introduction to data science course. 
Make sure to properly format your document. The `.html` version of the report is sufficient, and you can also include a report in additional formats if you choose to.