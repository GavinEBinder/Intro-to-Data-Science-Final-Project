# Final Project for Intro to Data Science

## Summer B 2021

Team members: 

- Student 1: [Gavin Binder](mailto:gbinder2005@floridapoly.edu)

- Student 2: [Joshua Mammah](mailto:jmammah1249@floridapoly.edu)

- Student 3: [Charles Ireland](mailto:cireland1675@floridapoly.edu)

- Student 4: [George Roig](mailto:groig1363@floridapoly.edu)

**Summary**

Our project investigates the main characteristics of video games.
We will be using the data available at: 
<https://github.com/rfordatascience/tidytuesday/blob/master/data/2019/2019-07-30/video_games.csv> 
